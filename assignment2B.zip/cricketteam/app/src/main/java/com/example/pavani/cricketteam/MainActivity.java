package com.example.pavani.cricketteam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4,b5,b6,b7;
    TextView t1,t2,t3,t4;
    int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);
        b5=(Button)findViewById(R.id.button5);
        b6=(Button)findViewById(R.id.button6);
        b7=(Button)findViewById(R.id.button7);

        t1=(TextView)findViewById(R.id.Text1);
        t2=(TextView)findViewById(R.id.Text2);
        t3=(TextView)findViewById(R.id.Text3);
        t4=(TextView)findViewById(R.id.Text4);


    }
    public void onClick(View view){

    }

    public void increasePoints(View v){

        int value = Integer.parseInt(t3.getText().toString());
        value+=3;
        t3.setText(String.valueOf(value));



    }
    public void increasePoints1(View v1){

        int value1 = Integer.parseInt(t3.getText().toString());
        value1+=2;
        t3.setText(String.valueOf(value1));
    }
    public void increasePoints2(View v2){

        int value2 = Integer.parseInt(t3.getText().toString());
        value2++;
        t3.setText(String.valueOf(value2));
    }

    public void increasePoints3(View v3){
        int value3 = Integer.parseInt(t1.getText().toString());
        value3+=3;
        t1.setText(String.valueOf(value3));

    }
    public void increasePoints4(View v4){

        int value4 = Integer.parseInt(t1.getText().toString());
        value4+=2;
        t1.setText(String.valueOf(value4));
    }
    public void increasePoints5(View v5){

        int value5 = Integer.parseInt(t1.getText().toString());
        value5++;
        t1.setText(String.valueOf(value5));
    }

    public void reset(View view) {

        t1.setText(""+count);
        t3.setText(""+count);
    }
}
