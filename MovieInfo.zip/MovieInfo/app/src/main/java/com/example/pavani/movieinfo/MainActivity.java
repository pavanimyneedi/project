package com.example.pavani.movieinfo;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.PersistableBundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import java.net.URL;

public class MainActivity extends AppCompatActivity {
    static final String API_KEY = BuildConfig.api;
    String key="storeState";
    static String valueState="";


    RecyclerView recyclerView;

    String url = "http://api.themoviedb.org/3/movie/popular?api_key=" + API_KEY;
    String url1 = "http://api.themoviedb.org/3/movie/top_rated?api_key=" + API_KEY;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.rec_tv);

        if (isConnected()) {
            Toast.makeText(getApplicationContext(), "Internet Connected", Toast.LENGTH_SHORT).show();
            if(savedInstanceState!=null)
            {
                if(savedInstanceState.containsKey(key))
                {
                    String v=savedInstanceState.getString(key);
                    if(v.equals("popular"))
                    {
                        MovieInfoTask info = new MovieInfoTask(this, recyclerView);
                        info.execute(url);
                    }
                    else if(v.equals("top_rated"))
                    {
                        MovieInfoTask info = new MovieInfoTask(this, recyclerView);
                        info.execute(url1);
                    }
                    else {
                        MovieInfoTask info = new MovieInfoTask(this, recyclerView);
                        info.execute(url);

                    }
                }
            }
            else {
                MovieInfoTask info = new MovieInfoTask(this, recyclerView);
                info.execute(url);
            }
        }
        else {
            Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
        }

    }
    public boolean isConnected() {
        boolean connected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = nInfo != null && nInfo.isAvailable() && nInfo.isConnected();
            return connected;
        } catch (Exception e) {
            Log.e("Connectivity Exception", e.getMessage());
        }
        return connected;
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_list, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.id_popular:
                if (isConnected()) {
                    valueState="popular";
                    Toast.makeText(getApplicationContext(), "Internet Connected", Toast.LENGTH_SHORT).show();
                    new MovieInfoTask(MainActivity.this,recyclerView).execute(url);
                } else {
                    Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.id_topRated:

                if (isConnected()) {
                    valueState="top_rated";
                    Toast.makeText(getApplicationContext(), "Internet Connected", Toast.LENGTH_SHORT).show();
                    new MovieInfoTask(MainActivity.this,recyclerView).execute(url1);
                } else {
                    Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
                break;
        }
        return true;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(key,valueState);
    }
}
