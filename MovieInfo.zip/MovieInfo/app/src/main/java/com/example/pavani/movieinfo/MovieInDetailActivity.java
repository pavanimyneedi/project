package com.example.pavani.movieinfo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class MovieInDetailActivity extends AppCompatActivity {

    TextView release_tv,rating_tv,des,title;
    ImageView poster_iv,back_drop_iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_in_detail);

        release_tv=(TextView)findViewById(R.id.rel_date);
        rating_tv=(TextView)findViewById(R.id.vote_avg);
        des=(TextView)findViewById(R.id.tv_synopsis);
        title=(TextView)findViewById(R.id.title_tv);

        poster_iv=(ImageView)findViewById(R.id.image_poster);
        back_drop_iv=(ImageView)findViewById(R.id.image_back);

        String[] getDetails=getIntent().getStringArrayExtra("details_required");


        boolean conn=new MainActivity().isConnected();
        if (conn==false) {
           // Toast.makeText(getApplicationContext(), "Internet Connected", Toast.LENGTH_SHORT).show();
            String poster=getDetails[1];
            String back_drop=getDetails[11];

            Picasso.with(this).load(poster).into(poster_iv);
            Picasso.with(this).load(back_drop).into(back_drop_iv);

            title.setText(getDetails[0]);
            release_tv.setText(getDetails[10]);
            rating_tv.setText(getDetails[7]);
            des.setText(getDetails[3]);
        } else {
            Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
        }


    }
}
