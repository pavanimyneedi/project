package com.example.pavani.ordercoffee;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3;
    TextView t1,t2,t3;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);

        t1=(TextView)findViewById(R.id.text_view1);
        t2=(TextView)findViewById(R.id.text_view2);
        t3=(TextView)findViewById(R.id.text_view3);
    }

    public void onClick(View view){

    }
    public void increaseQuantity(View v){

        int value = Integer.parseInt(t1.getText().toString());
        value++;
        t1.setText(String.valueOf(value));
    }

    public void decreaseQuantity(View v){

        int value1 = Integer.parseInt(t1.getText().toString());
        if (value1 > 0)
             value1--;
        t1.setText(String.valueOf(value1));
    }

    public void price(View v1){

        int value = Integer.parseInt(t1.getText().toString());
        int price = value * 40;

        t3.setText("Rs" + String.valueOf(price) + "/-");
    }
}
