package com.example.jokejavalib;

import java.util.Random;

public class myJoke {
    public static String[] Jokes={"hehehehe.....","ha ha ha ha .....",
            "uhuhuuhuh.....","hjvcsacvkauy","aschbeajcbaliue"};

    public String haveFun(){
        return Jokes[new Random().nextInt(Jokes.length -1)];
    }

}
