package com.udacity.gradle.builditbigger;

import android.content.Context;
import android.support.test.filters.LargeTest;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.test.AndroidTestCase;
import android.util.Pair;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


/**
 * Created by pavani on 19/6/18.
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class AsyncTaskTest extends AndroidTestCase implements JokeTask.onResponse{
    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity.class);
    private String joke;
    @Test
    public void AsyncTaskTest() throws InterruptedException,TimeoutException,ExecutionException{
        JokeTask jokeTask=new JokeTask();
        jokeTask.response=this;
       // jokeTask.execute(new Pair<Context, String>(getContext(), "sayHi"));
        jokeTask.execute(new Pair<Context, String>(getContext(),"sayHi"));
        joke = jokeTask.get(30, TimeUnit.SECONDS);
        assertTrue(joke, joke.length() > 0);
    }


    @Override
    public void done(String res) {

    }
}
